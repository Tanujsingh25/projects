package com.cg.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="bank_login")
public class Login {
	@Id
	@Column(name="user_name")
	private String username;
	@Column(name="password")
	private String password;
	public Login() {}
	public Login(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	@NotEmpty(message="UserName is mandatory")
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@NotEmpty(message="Password is mandatory")
	@Size(min=8,message="Password should contain at least 8 characters")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
} 
