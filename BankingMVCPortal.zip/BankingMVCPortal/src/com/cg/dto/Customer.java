package com.cg.dto;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "customerId", updatable = false, nullable = false)
	private int customerId;
	private String custName;
	private String custAddress;
	private long mobNo;
	@OneToOne(mappedBy = "customer",cascade=CascadeType.ALL)
	private Account account; 
	public Customer() {}
	public Customer(int customerId, String custName, String custAddress, long mobNo, Account account) {
		super();
		this.customerId = customerId;
		this.custName = custName;
		this.custAddress = custAddress;
		this.mobNo = mobNo;
		this.account = account;
	}
	public Customer(String custName, String custAddress, long mobNo) {
		super();
		this.custName = custName;
		this.custAddress = custAddress;
		this.mobNo = mobNo;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public long getMobNo() {
		return mobNo;
	}
	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + customerId + ", custName=" + custName + ", custAddress=" + custAddress + ", mobNo=" + mobNo
				+ ", account=" + account + "]";
	}

}
