package com.cg.service;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.TransactionDAO;
import com.cg.dao.AccountDAO;
import com.cg.dto.Account;
import com.cg.dto.Transaction;
@Service
public class BankingServiceImpl implements BankingService{
	@Autowired
	AccountDAO accountDAO;
	@Autowired
	TransactionDAO transactionDAO;
	public AccountDAO getAccountDAO() {
		return accountDAO;
	}
	public void setAccountDAO(AccountDAO accountDAO) {
		this.accountDAO = accountDAO;
	}	
	public TransactionDAO getTransactionDAO() {
		return transactionDAO;
	}
	public void setTransactionDAO(TransactionDAO transactionDAO) {
		this.transactionDAO = transactionDAO;
	}
	public BankingServiceImpl() {
		super();
	}
	@Override
	public Account openAccount(String accountType, float initBalance, String customerName, String mobileNo,
			String emailId, String dateOfBirth) {
		int pinNumber = Integer.parseInt(String.format("%04d", new Random().nextInt(8999)+1000));
		Account account = new Account(pinNumber, accountType, "Active", initBalance);
		accountDAO.save(account);
		Transaction transaction = new Transaction(initBalance, "NEW" ,account);
		transactionDAO.save(transaction);
		return account;
	}
	@Override
	public float depositAmount(long accountNo, float amount) {
		return 0;
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) {
		return 0;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) {
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo) {
		return null;
	}

	@Override
	public List<Account> getAllAccountDetails() {
		return null;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String accountStatus(long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pdfGenerator(long accountNo) {
		// TODO Auto-generated method stub
		
	}

}
