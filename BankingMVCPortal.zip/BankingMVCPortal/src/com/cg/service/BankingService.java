package com.cg.service;
import java.util.List;
import com.cg.dto.Account;
import com.cg.dto.Transaction;
public interface BankingService {
	Account openAccount(String accountType,float initBalance,String customerName,String mobileNo,String emailId,String dateOfBirth);
	float depositAmount(long accountNo,float amount);
	float withdrawAmount(long accountNo,float amount,int pinNumber);
	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber);
	Account getAccountDetails(long accountNo);
	List<Account> getAllAccountDetails();
	List<Transaction> getAccountAllTransaction(long accountNo);
	public String accountStatus(long accountNo);
	public void pdfGenerator(long accountNo);
}