package com.cg.dao;
import com.cg.dto.Customer;
public interface CustomerDao {
	Customer saveCustomer(Customer customer);
	Customer findCustomer(int customerId);
}
