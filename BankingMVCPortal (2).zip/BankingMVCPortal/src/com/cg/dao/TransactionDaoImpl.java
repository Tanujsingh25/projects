package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Transaction;
@Repository
@Transactional
public class TransactionDaoImpl implements TransactionDao{
	@PersistenceContext
	EntityManager entityManager;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	public TransactionDaoImpl() {
		super();
	}
	@Override
	public Transaction save(Transaction transaction){
		entityManager.persist(transaction);
		return transaction;
	}

}
