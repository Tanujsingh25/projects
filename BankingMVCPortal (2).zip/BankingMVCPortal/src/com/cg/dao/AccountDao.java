package com.cg.dao;

import com.cg.dto.Account;

public interface AccountDao {
	Account openAccount(Account account);
	float depositAmount(long accountNo,float amount);
}
