package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Customer;
@Repository
@Transactional
public class CustomerDaoImpl implements CustomerDao{
	@PersistenceContext
	EntityManager entityManager;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	public CustomerDaoImpl() {
		super();
	}
	@Override
	public Customer saveCustomer(Customer customer) {
		entityManager.persist(customer);
		return customer;
	}
	@Override
	public Customer findCustomer(int customerId) {
		return entityManager.find(Customer.class, customerId);
	}

}
