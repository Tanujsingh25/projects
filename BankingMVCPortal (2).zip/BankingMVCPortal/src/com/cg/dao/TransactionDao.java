package com.cg.dao;

import com.cg.dto.Transaction;

public interface TransactionDao {
	Transaction save(Transaction transaction);
}
