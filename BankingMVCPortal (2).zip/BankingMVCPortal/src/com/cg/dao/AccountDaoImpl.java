package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.dto.Account;
@Repository
@Transactional
public class AccountDaoImpl implements AccountDao{
	@PersistenceContext
	EntityManager entityManager;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	public AccountDaoImpl() {
		super();
	}
	@Override
	public Account openAccount(Account account) {
		entityManager.persist(account);
		return account;
	}
	@Override
	public float depositAmount(long accountNo, float amount) {
		
		return 0;
	}

}
