package com.cg.service;
import com.cg.dto.Account;
import com.cg.dto.Customer;
public interface BankingService {
	Customer saveCustomer(Customer customer);
	Customer findCustomer(int customerId);
	float depositAmount(long accountNo,float amount);
	Account openAccount(String accountType,float initialBalance);
}
