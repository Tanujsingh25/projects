package com.cg.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.AccountDao;
import com.cg.dao.CustomerDao;
import com.cg.dao.TransactionDao;
import com.cg.dto.Account;
import com.cg.dto.Customer;
import com.cg.dto.Transaction;
@Service
public class BankingServiceImpl implements BankingService{
	@Autowired
	CustomerDao customerDao;
	@Autowired
	AccountDao accountDao;
	@Autowired
	TransactionDao transactionDao;
	public CustomerDao getCustomerDao() {
		return customerDao;
	}
	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}
	public AccountDao getAccountDao() {
		return accountDao;
	}
	public void setAccountDao(AccountDao accountDao) {
		this.accountDao = accountDao;
	}
	public TransactionDao getTransactionDao() {
		return transactionDao;
	}
	public void setTransactionDao(TransactionDao transactionDao) {
		this.transactionDao = transactionDao;
	}
	public BankingServiceImpl() {
		super();
	}
	@Override
	public Customer saveCustomer(Customer customer) {
		return customerDao.saveCustomer(customer);
	}

	@Override
	public Customer findCustomer(int customerId) {
		return customerDao.findCustomer(customerId);
	}
	@Override
	public Account openAccount(String accountType, float initialBalance) {
		int pinNumber = Integer.parseInt(String.format("%04d", new Random().nextInt(8999)+1000));
		Account account = new Account(pinNumber, accountType, "Active", initialBalance);
		accountDao.openAccount(account);
		transactionDao.save(new Transaction(initialBalance, "NEW" ,account));
		return accountDao.openAccount(account);
	}
	@Override
	public float depositAmount(long accountNo, float amount) {
		return accountDao.depositAmount(accountNo, amount);
	}

}
