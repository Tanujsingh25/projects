package com.cg.ctrl;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.dto.Account;
import com.cg.dto.Customer;
import com.cg.service.BankingService;
@Controller
public class BankingController {
	@Autowired
	BankingService bankingService;
	public BankingService getBankingService() {
		return bankingService;
	}
	public void setBankingService(BankingService bankingService) {
		this.bankingService = bankingService;
	}
	public BankingController() {
		super();
	}
	@RequestMapping(value="showHomePage",method=RequestMethod.GET)
	public String showHomePage(Model model) {
		model.addAttribute("account",new Account());
		return "HomePage";
	}
	@RequestMapping(value="login", method=RequestMethod.POST)
	public String displayLoginPage(Model model,@ModelAttribute(value="account") @Valid Account account,BindingResult result){
		model.addAttribute("customer", bankingService.findCustomer(account.getCustomer().getCustomerId()));
		return "MenuPage";
	}
	@RequestMapping(value="register",method=RequestMethod.POST)
	public String SuccessRegisterPage(Model model,@ModelAttribute(value="account") @Valid Account account,BindingResult result){
		System.out.println(account.toString());
		Customer customer = bankingService.saveCustomer(account.getCustomer());
		System.out.println(customer);
		model.addAttribute("acc",account);
		model.addAttribute("cust",customer);
		return "SuccessRegisterPage";
	}
	@RequestMapping(value="openAcc",method=RequestMethod.POST)
	public String openAccount(Model model,@ModelAttribute(value="account") @Valid Account account,BindingResult result) {
		model.addAttribute("account",bankingService.openAccount(account.getAccountType(), account.getAccountBalance()));
		return "AccountSuccessfullyOpenPage";
	}
	
	@RequestMapping(value="deposit",method=RequestMethod.POST)
	public String depositAmount(Model model,@ModelAttribute(value="account") @Valid Account account,BindingResult result){
		//account.depositAmount();
		return "";
	}
	
}
